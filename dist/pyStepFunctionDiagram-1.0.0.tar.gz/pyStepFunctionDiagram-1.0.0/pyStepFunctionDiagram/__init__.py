
#############################################################################################################################
#   filename:pyStepFunctionDiagram.py                                                       
#   created: 2023-05-03                                                              
#   import your librarys below                                                    
#############################################################################################################################



from .pyStepFunctionDiagram import *


#sfnDiagram('/home/bates/Documents/Repositorios/hello/hello')
